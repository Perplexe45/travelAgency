OceanWP Child Theme
=================

Ready-to-Use Child Theme for the OceanWP free WordPress theme.

### Usage
Download the child theme zip file. Upload the zip (oceanwp-child-theme-master.zip) under your WordPress dashboard, Appearance > Themes.The other method would be to extract files and upload via FTP at wp-content/themes/.


### Renaming
You can rename the zip file so it isn't called oceanwp-child-theme-master.zip.
You can also change the "Theme Name" at the top of the style.css file, as well as the rest of information in the same file. This is called whitelabeling a child theme.
